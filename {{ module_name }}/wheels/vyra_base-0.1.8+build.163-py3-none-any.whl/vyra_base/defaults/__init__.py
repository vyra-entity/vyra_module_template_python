"""
This module provides default constants, entries, exceptions, and author information
for the vyra_base package.

:author: See AuthorInfo
"""

from .constants import (
    MODULE_ID_NAMESPACE,
)
from .entries import (
    ErrorEntry,
    NewsEntry,
    StateEntry,
    ModuleEntry,
    InterfaceKind,
    InterfaceProtocol,
    InterfaceParamType,
    InterfaceParam,
    InterfaceReturn,
    InterfaceDisplayStyle,
    InterfacePeriodicPublisher,
    FunctionConfigEntry,
    # backward-compatible re-exports
    FunctionConfigBaseTypes,
    FunctionConfigTags,
    FunctionConfigParamTypes,
    FunctionConfigBaseParams,
    FunctionConfigBaseReturn,
    FunctionConfigDisplaystyle,
    FunctionConfigPeriodicPublisher,
)
from .exceptions import FeederException
