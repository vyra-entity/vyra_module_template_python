from __future__ import annotations

import uuid
from dataclasses import asdict, dataclass, field, is_dataclass, fields
from datetime import datetime
from enum import Enum, IntEnum
from re import DEBUG
from typing import Any, Callable, Union
from uuid import UUID

try:
    from rclpy.qos import QoSProfile  # type: ignore[import]
except ImportError:  # ROS2 not installed (e.g. dashboard-only containers)
    pass
from vyra_base.helper.error_handler import ErrorTraceback


class InterfaceParamType(Enum):
    """
    Wire-level data types for interface parameters and return values.

    Values match the ``datatype`` strings used in ``*.meta.json`` files.
    """
    BOOL = "bool"
    BYTE = "byte"
    CHAR = "char"
    INT8 = "int8"
    UINT8 = "uint8"
    INT16 = "int16"
    UINT16 = "uint16"
    INT32 = "int32"
    UINT32 = "uint32"
    INT64 = "int64"
    UINT64 = "uint64"
    FLOAT32 = "float32"
    FLOAT64 = "float64"
    STRING = "string"
    TIME = "time"
    DURATION = "duration"
    ANY = "any"
    NONE = "none"
    ARRAY = "array"


@dataclass(slots=True)
class DCBase:
    """
    Base dataclass providing utility methods for all VYRA dataclass entries.
    
    Provides common functionality like dict conversion for dataclass instances.
    """
    def asdict(self):
        """
        Convert the dataclass instance to a dictionary.
        
        :return: Dictionary representation of the dataclass.
        :rtype: dict
        """
        return asdict(self)

class InterfaceKind(Enum):
    """Communication pattern of an interface (message / service / action)."""
    message = 'message'
    service = 'service'
    action = 'action'


class InterfaceProtocol(str, Enum):
    """
    Transport protocol tags for interface entries.

    Using ``str, Enum`` so values compare equal to plain strings and
    serialise cleanly to JSON.
    """
    ROS2 = "ros2"
    ZENOH = "zenoh"
    REDIS = "redis"
    UDS = "uds"


@dataclass(slots=True)
class InterfaceParam(DCBase):
    """Descriptor for a single service/action request parameter."""
    datatype: InterfaceParamType
    displayname: str
    description: str
    name: str = ""


@dataclass(slots=True)
class InterfaceReturn(DCBase):
    """Descriptor for a single service/action response field."""
    datatype: InterfaceParamType
    displayname: str
    description: str
    name: str = ""


@dataclass(slots=True)
class InterfaceDisplayStyle(DCBase):
    """Controls how an interface is shown in the VYRA dashboard."""
    visible: bool = False
    published: bool = False


@dataclass(slots=True)
class InterfacePeriodicPublisher(DCBase):
    """
    Stores the periodic publisher settings.

    :param caller: The function to be called periodically
    :type caller: Callable
    :param interval: The time interval in seconds for the periodic call (default: 1.0, must be between 0.01 and 10.0)
    :type interval: float

    :raises ValueError: If the interval is not between 0.01 and 10.0 seconds
    """
    caller: Callable
    interval: float = 1.0

    def __post_init__(self):
        if not (0.01 <= self.interval <= 10.0):
            raise ValueError(f"speed {self.interval} out of bounds (0.01–10.0)")

    def asdict(self):
        """
        Convert periodic publisher config to dictionary, replacing callable with name.
        
        :return: Dictionary with caller function name instead of reference.
        :rtype: dict
        """
        result = {}
        for f in fields(self):
            if f.name == "caller":
                result[f.name] = getattr(self.caller, "__name__", None)
                continue
            value = getattr(self, f.name)
            result[f.name] = value
        return result


@dataclass(slots=True)
class FunctionConfigEntry(DCBase):
    """
    Contains the function configuration.

    Stores the function settings for type safety and DDS communication node configuration.

    :param tags: Tags for the function
    :type tags: list[FunctionConfigTags]
    :param type: Type of the function
    :type type: FunctionConfigBaseTypes
    :param interfacetypes: Interface types of the function
    :type interfacetypes: Any
    :param functionname: Name of the function
    :type functionname: str
    :param displayname: Display name of the function
    :type displayname: str
    :param description: Description of the function
    :type description: str
    :param displaystyle: Display style of the function
    :type displaystyle: FunctionConfigDisplaystyle
    :param params: Parameters of the function
    :type params: list[FunctionConfigBaseParams]
    :param returns: Return values of the function
    :type returns: list[FunctionConfigBaseReturn]
    :param qosprofile: Quality of Service profile (default: 10)
    :type qosprofile: Union[int, QoSProfile]
    :param callbacks: Functions to be called when the function is invoked (only for callable)
    :type callbacks: list[Callable], Optional
    :param periodic: Function to be called periodically (only for publisher)
    :type periodic: FunctionConfigPeriodicPublisher, Optional
    :param namespace: Optional topic namespace segment inserted between module id and function name
    :type namespace: str, Optional
    :param subsection: Optional sub-topic segment appended after the function name
    :type subsection: str, Optional
    """
    tags: list[InterfaceProtocol]
    type: InterfaceKind
    interfacetypes: Any
    functionname: str
    displayname: str
    description: str
    displaystyle: InterfaceDisplayStyle
    params: list[InterfaceParam] = field(default_factory=list)
    returns: list[InterfaceReturn] = field(default_factory=list)
    qosprofile: Union[int, QoSProfile] = 10
    callbacks: Union[dict[str, Callable], None] = None
    periodic: Union[InterfacePeriodicPublisher, None] = None
    namespace: Union[str, None] = None
    subsection: Union[str, None] = None

    @classmethod
    def from_manifest(cls, data: dict[str, Any]) -> FunctionConfigEntry:
        """Build a :class:`FunctionConfigEntry` from a raw ``*.meta.json`` dict."""
        ds_raw = data.get("displaystyle", {})
        displaystyle = InterfaceDisplayStyle(
            visible=ds_raw.get("visible", False),
            published=ds_raw.get("published", False),
        )
        tags = [
            InterfaceProtocol(t)
            for t in data.get("tags", [])
            if t in InterfaceProtocol._value2member_map_
        ]
        kind_raw = data.get("type", InterfaceKind.service.value)
        kind = (
            InterfaceKind(kind_raw)
            if kind_raw in InterfaceKind._value2member_map_
            else InterfaceKind.service
        )
        return cls(
            tags=tags,
            type=kind,
            interfacetypes=data.get("interfacetypes"),
            functionname=data["functionname"],
            displayname=data.get("displayname", data["functionname"]),
            description=data.get("description", ""),
            displaystyle=displaystyle,
            params=_parse_interface_params(data.get("params", [])),
            returns=_parse_interface_returns(data.get("returns", [])),
            namespace=data.get("namespace"),
            qosprofile=data.get("qosprofile", 10),
            callbacks=data.get("callbacks"),
            periodic=data.get("periodic"),
            subsection=data.get("subsection"),
        )

    def asdict(self):
        """
        Convert FunctionConfigEntry to a JSON-serialisable dictionary.
        """
        result = {}
        for f in fields(self):
            if f.name == "callbacks":
                result[f.name] = (
                    {name: getattr(cb, "__name__", None) for name, cb in self.callbacks.items()}
                    if self.callbacks
                    else None
                )
                continue
            if f.name == "interfacetypes":
                value = self.interfacetypes
                if isinstance(value, list):
                    result[f.name] = [
                        getattr(v, "__name__", v) if not isinstance(v, str) else v
                        for v in value
                    ]
                else:
                    result[f.name] = getattr(value, "__name__", value)
                continue
            if f.name == "displaystyle":
                result[f.name] = self.displaystyle.asdict()
                continue
            if f.name == "type":
                result["type"] = self.type.value
                continue
            if f.name == "tags":
                result[f.name] = [t.value for t in self.tags]
                continue
            value = getattr(self, f.name)
            if f.name == "params":
                result[f.name] = [
                    {
                        **p.asdict(),
                        "datatype": p.datatype.value,
                    }
                    for p in self.params
                ]
                continue
            if f.name == "returns":
                result[f.name] = [
                    {
                        **r.asdict(),
                        "datatype": r.datatype.value,
                    }
                    for r in self.returns
                ]
                continue
            result[f.name] = value
        return result


def _coerce_param_type(raw: Any) -> InterfaceParamType:
    if isinstance(raw, InterfaceParamType):
        return raw
    text = str(raw).lower().split("[", 1)[0].strip()
    if text in InterfaceParamType._value2member_map_:
        return InterfaceParamType(text)
    return InterfaceParamType.STRING


def _parse_interface_params(items: list[Any]) -> list[InterfaceParam]:
    result: list[InterfaceParam] = []
    for item in items:
        if isinstance(item, InterfaceParam):
            result.append(item)
            continue
        if not isinstance(item, dict):
            continue
        result.append(
            InterfaceParam(
                name=item.get("name", ""),
                datatype=_coerce_param_type(item.get("datatype", "string")),
                displayname=item.get("displayname", item.get("name", "")),
                description=item.get("description", ""),
            )
        )
    return result


def _parse_interface_returns(items: list[Any]) -> list[InterfaceReturn]:
    result: list[InterfaceReturn] = []
    for item in items:
        if isinstance(item, InterfaceReturn):
            result.append(item)
            continue
        if not isinstance(item, dict):
            continue
        result.append(
            InterfaceReturn(
                name=item.get("name", ""),
                datatype=_coerce_param_type(item.get("datatype", "string")),
                displayname=item.get("displayname", item.get("name", "")),
                description=item.get("description", ""),
            )
        )
    return result


# Backward-compatible aliases (deprecated names)
FunctionConfigParamTypes = InterfaceParamType
FunctionConfigBaseTypes = InterfaceKind
FunctionConfigTags = InterfaceProtocol
FunctionConfigBaseParams = InterfaceParam
FunctionConfigBaseReturn = InterfaceReturn
FunctionConfigDisplaystyle = InterfaceDisplayStyle
FunctionConfigPeriodicPublisher = InterfacePeriodicPublisher


@dataclass(slots=True)
class ErrorEntry(DCBase):
    """
    Container for the error entry.

    Stores the error details.

    :param level: The level of the error (default: 0, MINOR_FAULT)
    :type level: Union[ErrorEntry.ERROR_LEVEL, int]
    :param code: The error code (default: 0x00000000)
    :type code: int
    :param uuid: Unique identifier for the error entry
    :type uuid: Union[UUID, Any]
    :param timestamp: Timestamp of when the error occurred
    :type timestamp: Any
    :param description: Description of the error
    :type description: str
    :param solution: Suggested solution for the error
    :type solution: str
    :param miscellaneous: Additional information about the error
    :type miscellaneous: str
    :param module_name: Name of the module where the error occurred
    :type module_name: str
    :param module_id: Unique identifier for the module
    :type module_id: Union[UUID, Any]
    """
    level: Union["ErrorEntry.ERROR_LEVEL", int] = 0
    code: int = 0x00000000
    uuid: Union[UUID, Any] = field(default_factory=uuid.uuid4)
    timestamp: Any = ''
    description: str = ''
    solution: str = ''
    miscellaneous: str = ''
    module_name: str = 'N/A'
    module_id: Union[UUID, Any] = 'N/A'

    def __repr__(self) -> str:
        return (
            f"ErrorEntry(level={self.level}, code={self.code}, "
            f"description={self.description}, solution={self.solution}"
        )

    class ERROR_LEVEL(IntEnum):
        """
        Enum for the error level.

        :cvar MINOR_FAULT: Minor fault (0)
        :cvar MAJOR_FAULT: Major fault (1)
        :cvar CRITICAL_FAULT: Critical fault (2)
        :cvar EMERGENCY_FAULT: Emergency fault (3)
        """
        MINOR_FAULT = 0
        MAJOR_FAULT = 1
        CRITICAL_FAULT = 2
        EMERGENCY_FAULT = 3


class NewsEntry(dict):
    """
    News feed entry object.

    Writes informational data to the graphical user interface.

    :param level: The level of the message (default: 2, INFO)
    :type level: Union[NewsEntry.MESSAGE_LEVEL, int]
    :param message: The message content
    :type message: str
    :param timestamp: Timestamp of when the message was created
    :type timestamp: Any
    :param uuid: Unique identifier for the news entry
    :type uuid: Union[UUID, Any]
    :param module_name: Name of the module that created the news entry
    :type module_name: str
    :param module_id: Unique identifier for the module
    :type module_id: Union[UUID, Any]
    """
    __slots__ = (
        'level',
        'message',
        'timestamp',
        'uuid',
        'module_name',
        'module_id'
    )

    def __init__(
        self,
        level: Union["NewsEntry.MESSAGE_LEVEL", int] = 2,
        message: str = '',
        timestamp: Any = datetime.now(),
        uuid: Union[UUID, Any] = uuid.uuid4(),
        module_name: str = 'N/A',
        module_id: Union[UUID, Any] = uuid.uuid4(),
    ) -> None:
        self.message: str = message
        self.level: Union[NewsEntry.MESSAGE_LEVEL, int] = level
        self.timestamp: Union[datetime, Any] = timestamp
        self.uuid: Union[UUID, Any] = uuid
        self.module_name: str = module_name
        self.module_id: Union[UUID, Any] = module_id

    def __repr__(self) -> str:
        return (
            f"NewsEntry(level={self.level}, message={self.message}"
        )

    class MESSAGE_LEVEL(IntEnum):
        """
        Enum for the message type.

        :cvar ACTION: Action message (0)
        :cvar DEBUG: Debug message (1)
        :cvar INFO: Info message (2)
        :cvar HINT: Hint message (3)
        :cvar WARNING: Warning message (4)
        """
        ACTION = 0
        DEBUG = 1
        INFO = 2
        HINT = 3
        WARNING = 4


@dataclass(repr=True, slots=True)
class StateEntry(DCBase):
    """
    Contains the state entry.

    Stores the state details for life cycle overview of the module.

    :param current: Current state of the module
    :type current: str
    :param trigger: Trigger that caused the state change
    :type trigger: str
    :param module_id: Unique identifier for the module
    :type module_id: Union[UUID, Any]
    :param module_name: Name of the module
    :type module_name: str
    :param timestamp: Timestamp of when the state was recorded
    :type timestamp: Any
    :param previous: Previous state of the module (default: 'N/A')
    :type previous: str
    """
    current: str
    trigger: str
    module_id: Union[UUID, Any]
    module_name: str
    timestamp: Any
    previous: str = 'N/A'

    def __repr__(self) -> str:
        return (
            f"StateEntry(current={self.current}, trigger={self.trigger}, "
            f"previous={self.previous})"
        )

@dataclass(slots=True)
class ModuleEntry(DCBase):
    """
    Contains the module entry.

    Stores the module details.

    :param uuid: Unique identifier for the module
    :type uuid: UUID
    :param name: Name of the module
    :type name: str
    :param blueprints: Blueprint identifier(s) for the module
    :type blueprints: str
    :param description: Description of the module
    :type description: str
    :param version: Version of the module (semantic versioning, e.g. '1.0.0')
    :type version: str
    """
    uuid: str
    name: str
    blueprints: str
    description: str
    version: str

    def __repr__(self) -> str:
        return (
            f"ModuleEntry(uuid={self.uuid}, name={self.name}, "
            f"blueprints={self.blueprints}, description={self.description}, "
            f"version={self.version})"
        )
    
    def to_dict(self) -> dict:
        """
        Returns the dictionary representation of the ModuleEntry.

        :return: Dictionary containing the module details.
        :rtype: dict
        """
        return {
            'uuid': str(self.uuid),
            'name': self.name,
            'blueprints': self.blueprints,
            'description': self.description,
            'version': self.version
        }

    @staticmethod
    def gen_uuid() -> str:
        """Generates a new UUID for the module entry in hex format"""
        return uuid.uuid4().hex

    def restructure_uuid(self) -> UUID:
        """
        Converts the UUID string to a UUID object.

        :return: UUID object of the module entry.
        :rtype: UUID
        """
        return uuid.UUID(hex=self.uuid)
